# The No-Nonsense Guide to Assembly

A free, complete, hands-on course in x86-64 assembly language, from the anatomy of the machine to a 512-byte operating system that boots on bare hardware. By Eden Gilbert Kiseka, published by Carthigan.

**377 pages · 30 chapters · 6 parts · 55+ original diagrams · every program verified on real Linux**

[Read the book (PDF)](https://carthigan.com/books/no-nonsense-guide-to-assembly.pdf) · [Book page](https://carthigan.com/education/assembly-book) · [Releases](../../releases)

![The No-Nonsense Guide to Assembly](cover.png)

## What this book is

No magic. No hidden safety nets. Every instruction you write corresponds to one hardware operation inside the silicon. This book takes you from "what is a register" to writing your own web server, memory allocator, and bootable OS, entirely in pure x86-64 NASM assembly on Linux. No C library required (except where the chapter is about calling the C library).

- **Every program runs.** Each was assembled and executed on a real Linux machine; the book shows real debugger sessions, a real HTTP exchange, and a real QEMU screenshot of the boot OS.
- **Answers to every chapter's exercises**, plus five complete worked programs in the appendix.
- **55+ original diagrams** in a consistent visual language: the stack, registers, instruction encoding, race conditions, and the boot process, drawn to be read.

## The course

| Part | Chapters | You will |
|---|---|---|
| I. The Machine | 1-5 | Understand the CPU, write and run your first program, master `mov`, memory addressing, and arithmetic |
| II. Control Flow, the Stack, and Functions | 6-10 | Branch, use the hardware stack, call functions under the System V ABI, and build an interactive calculator |
| III. Talking to the Operating System | 11-16 | Read arguments, open files, allocate memory, build linked lists, call C, and organize projects with macros |
| IV. Performance | 17-20 | Do floating-point and SIMD math, go branchless with `cmov`, run real threads, and inline assembly in C and Rust |
| V. Under the Surface | 21-25 | Read raw instruction encodings, debug with GDB, understand stack-smashing exploits, build shared libraries, take over the terminal |
| VI. Real Software, from Scratch | 26-30 | Build a hex dumper, a Unix shell, a web server, a malloc, and an operating system that boots from 512 bytes |

## Getting the book

- **PDF**: https://carthigan.com/books/no-nonsense-guide-to-assembly.pdf
- **GitHub Releases**: the latest PDF is attached to each [release](../../releases)
- **Web**: https://carthigan.com/education/assembly-book

No email, no paywall, no signup.

## Building from source

Requires XeLaTeX (TeX Live 2024 or later) and the Times New Roman font:

```bash
xelatex main.tex   # run twice for the table of contents
open main.pdf
```

## Repository layout

```
main.tex              master file
preamble.tex          design system: fonts, colors, boxes, listings
front/                title page, copyright, preface, about the author
chapters/             30 chapter files (ch01.tex ... ch30.tex)
appendices/           exercise answers, worked programs, quick reference, glossary
figures/              the QEMU boot screenshot used in Chapter 30
captures/             real program output captured on Linux, typeset in the book
```

## License

- **Text**: [CC BY 4.0](LICENSE-CC-BY-4.0) - share and adapt freely, commercially included, with attribution
- **Code listings**: [MIT](LICENSE-MIT)

## Errata

Found a mistake? Open an [issue](../../issues). Corrections land in the next release.

## About the author

Eden Gilbert Kiseka is a software and electronics engineer in Kampala, Uganda, and the founder of [Carthigan](https://carthigan.com). He taught embedded systems programming at Neriko Electronics, where he built the curriculum and the hands-on labs from scratch. He wrote this book to be the course he wished his students had.
