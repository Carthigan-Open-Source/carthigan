# House Style Contract for Chapter Writers

This book, *The No-Nonsense Guide to Assembly* by Eden Gilbert Kisekka, is a
real published technical book. Every chapter file must obey this contract.

## Absolute rules

1. **No em dashes (—) and no en dashes (–), anywhere**, including inside code
   comments and figure labels. Use a comma, colon, parentheses, or restructure
   the sentence. Numeric ranges use a plain hyphen: 0-255, 1-100.
2. **No math mode.** Never type a `$`. Powers are text: `2\textsuperscript{8} = 256`.
   Multiplication in prose is the word "times" or an explicit product like
   `128 + 64 + 32 + 16 + 8 + 4 + 2 + 1 = 255`.
3. **ASCII characters only in prose.** Escape every underscore as `\_`, for
   example `\code{sys\_write}`, `\code{msg\_len}`. Quotes are ``` ``double'' ```
   and apostrophes are plain `'`.
4. **Use only the macros and environments defined in `book/preamble.tex`**,
   combined exactly the way `book/chapters/_sample.tex` shows. That file is the
   pattern. The available pieces are:
   - `\code{...}` for inline code and register names
   - `keybox`, `warnbox`, `trapbox` (titled boxes, 1 to 3 per chapter maximum)
   - `asm` and `clisting` listings environments, always with `title={file.ext}`
   - `figure` + `tikzpicture` with preamble styles: `block`, `accblock`,
     `memcell`, `regcell`, `flow`, `flowacc`, `dashedflow`, `lbl`
   - `table` + `tabular` with `booktabs` rules only, never vertical lines
   - `terminal` for typeset terminal transcripts (real session text; wrap
     typed commands in `\tp{...}`, accents in `\tc{...}`, lines end with `\par`)
   - `vgascreen` for full-width VGA text screens such as the boot screen
   - `\includegraphics` for image files the lead provides in `figures/`
   - `recap` environment (the What you learned box, 4-8 bullets)
   - `exercises` environment (3-6 items, derived from this chapter's content)
   - `\textsuperscript` for powers
5. **All technical content comes from your assigned source ranges only.** No
   invented facts, no extra syscalls, no instructions that are not in the
   source. When the source is wrong about something listed in your errata,
   fix it. When you spot a different source error, fix it and report it.
6. **Merge duplicates.** Where your ranges tell the same idea twice, keep the
   clearer explanation and the better example, not both.
7. **Voice.** Plain, direct, second person. Short paragraphs. Concrete over
   abstract. Confident without hype. No filler phrases ("it is worth noting",
   "in today's world", "delve into"). Never address the reader as "dear".
8. **Figures.** Every figure goes in a `figure[htbp]` environment with a
   caption and a `\label{fig:chNN-...}` label. Keep TikZ pictures under about
   7.5 cm tall or they will not fit the 6 by 9 page. Prefer many small clean
   diagrams over one crowded one.
9. **Tables.** `\label{tab:chNN-...}`. Listings need no label unless the text
   refers back to them; if it does, use `\begin{asm}[title={x.asm}, caption={...}]`.
10. **Every chapter ends with `recap` then `exercises`.** Exercises are derived
    from the chapter's own material: modify the program, trace a value, extend
    a diagram. No exercises that need knowledge from later chapters.
11. **Chapter heading** is `\chapter{Title in Title Case}`. No manual numbering.
12. No `\footnote`, no `\cite`, no URLs, no `\part` (parts live in main.tex),
    no `\appendix`, no `documentclass`, no `\begin{document}`.
13. The file you write is your only output. Do not touch any other file.

## Length

Cover all of your source material at a natural density. Length is an outcome,
not a goal: do not pad, do not summarize away runnable code. The per-chapter
word targets in `buildplan.md` are guides within about 20 percent.

## Source handling notes

- The source is a rough manuscript with copy-paste artifacts, mangled math
  notation, and duplicated chapters. You are the final author pass.
- Where the source shows inline code as ASCII art tables or box drawings,
  convert them into proper TikZ figures or booktabs tables.
- Keep every complete runnable program from your ranges as a full listing
  with its assemble/link/run comments. Trim redundant commentary around them,
  never the programs themselves.
- If two of your source ranges contradict each other technically, keep the
  correct one, note the conflict in your report.
